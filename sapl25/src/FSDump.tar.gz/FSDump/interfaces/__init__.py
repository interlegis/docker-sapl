""" FSDump product interfaces.

$Id$
"""
